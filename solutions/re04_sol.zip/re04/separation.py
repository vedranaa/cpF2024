"""Exercise 4.13: Degrees of Separation."""

def degrees_of_separation(users, start, end,visited):
    """Find the degrees of separation between two users (start and end)
    If the start and end users are the same, the degrees of separation is 0.
    If the start user and the end user have no connection, the degrees of separation is float('inf').
    
    :param users: a dictionary containing the users and their friends.
    :param start: the starting user.
    :param end: the ending user.
    :param visited: a set of visited users.
    
    :return: the degrees of separation.
    """
    #!b;nolines;noerror
    if start == end:
        return 0
    if start in visited:
        return float('inf')
    visited.add(start)
    friends = users[start]
    degrees = float('inf')
    for friend in friends:
        degrees = min(degrees, 1 + degrees_of_separation(users, friend, end, visited))
    return degrees #!b