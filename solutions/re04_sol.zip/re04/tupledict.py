"""Exercise 4.9: Turn a list of tuples into a dictionary."""

def tuple_list_to_dict(lst):
    """Turn a list of tuples into a dictionary.

    :param lst: a list of tuples.
    
    :return: a dictionary.
    """
    #!b;nolines;noerror
    return dict(lst) #!b