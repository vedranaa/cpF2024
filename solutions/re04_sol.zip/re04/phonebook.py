"""Exercise 4.12: Phonebook areacode percentage."""

areacode = {
    "CA": ["408", "415", "831", "510"],
    "NY": ["212", "646", "917"],
    "WA": ["206", "425"],
    "TX": ["214", "469"],
    "FL": ["305", "954"],
    "CO": ["303", "970"],
    "DC": ["202"],
    "VA": ["703"],
    "IL": ["312"],
    "MI": ["313"],
    "OH": ["216"]
}

def percentage(phonebook):
    """Create a dictionary with the state as key and the percentage of phone numbers with that state's area code as value.

    :param phonebook: a dictionary containing names and phone numbers.
    
    :return: a dictionary with the state as key and the percentage of phone numbers with that state's area code as value.
    """
    #!b;nolines;noerror
    ret = {}
    total = len(phonebook)
    for state, codes in areacode.items():
        count = 0
        for code in codes:
            for phone in phonebook.values():
                if phone.startswith(code):
                    count += 1
        ret[state] = count
    return {state: 100*count / total for state, count in ret.items()} #!b