"""Exercise 4.11: Department top salaries."""

def salaries(d,department, k):
    """Return the top k salaries in a department.

    :param d: a dictionary where the key is the employee and the value is a tuple of the salary and the department.
    :param department: the department to filter.
    :param k: the number of top salaries to return.

    :return: a list of tuples with the top salaries.
    """
    #!b;nolines;noerror
    return sorted([(k,v) for k,v in d.items() if v[1] == department], key=lambda x: x[1][0], reverse=True)[:k]
    #!b