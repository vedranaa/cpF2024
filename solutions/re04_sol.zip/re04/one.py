"""Exercise 4.8: Find out if there are any dictionary values that go again"""

def one_to_one(d):
    """Find out if there are any dictionary values that go against the one-to-one principle.
    
    :param d: a dictionary.
    
    :return: a boolean value.
    """
    #!b;nolines;noerror
    return len(set(d.values())) == len(d) #!b