"""Exercise 4.5: Encryption via Dictionary"""

def encrypt(text, key):
    """Encrypt a text using a dictionary.

    :param text: a string.
    :param key: a dictionary.

    :return: a string.
    """
    #!b;nolines;noerror
    return ''.join([key[char] for char in text]) #!b