"""Exercise 4.7: Stem and Leaf dictionary."""

def stem_and_leaf(data, key):
    """Stem and Leaf dictionary.

    :param data: a list of integers.
    :param key: an integer.

    :return: a dictionary containing the stems as keys and the leaves as values.
    """
    #!b;nolines;noerror
    stem_leaf = {}
    for num in data:
        stem = num // key
        leaf = num % key
        if stem in stem_leaf:
            stem_leaf[stem].append(leaf)
        else:
            stem_leaf[stem] = [leaf]
    return stem_leaf #!b