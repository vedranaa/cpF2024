"""Exercise 4.4: Extract Key's Value if key is present in list and dictionary."""

def extract_key_value(lst, dict):
    """Extract Key's Value if key is present in list and dictionary.
    
    :param lst: a list of keys.
    :param dict: a dictionary.
    
    :return: the value corresponding to the key in the data.
    """
    #!b;nolines;noerror
    return [dict[key] for key in lst if key in dict] #!b