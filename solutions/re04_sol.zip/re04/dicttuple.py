"""Exercise 4.10: Turn a dictionary into a list of tuples."""

def dict_to_tuple_list(d):
    """Turn a dictionary into a list of tuples.

    :param d: a dictionary.
    
    :return: a list of tuples.
    """
    #!b;nolines;noerror
    return list(d.items()) #!b