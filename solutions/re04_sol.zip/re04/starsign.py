"""Exercise 4.6: Star Sign."""

signs = {
    'aries': ('21/03', '20/04', 'fire', 'mars'),
    'taurus': ('21/04', '20/05', 'earth', 'venus'),
    'gemini': ('21/05', '20/06', 'air', 'mercury'),
    'cancer': ('21/06', '22/07', 'water', 'moon'),
    'leo': ('23/07', '22/08', 'fire', 'sun'),
    'virgo': ('23/08', '22/09', 'earth', 'mercury'),
    'libra': ('23/09', '22/10', 'air', 'venus'),
    'scorpio': ('23/10', '21/11', 'water', 'mars'),
    'sagittarius': ('22/11', '21/12', 'fire', 'jupiter'),
    'capricorn': ('22/12', '19/01', 'earth', 'saturn'),
    'aquarius': ('20/01', '18/02', 'air', 'uranus'),
    'pisces': ('19/02', '20/03', 'water', 'neptune')
}

def starsign(date):
    """Return the star sign, element and ruling planet for a given date.
    
    :param date: a string in the format 'dd/mm'.
    
    :return: a tuple containing the star sign, element and ruling planet.
    """
    #!b;nolines;noerror
    day, month = map(int, date.split('/'))
    for sign, (start, end, element, planet) in signs.items():
        start_day, start_month = map(int, start.split('/'))
        end_day, end_month = map(int, end.split('/'))
        if (month == start_month and day >= start_day) or (month == end_month and day <= end_day):
            return sign, element, planet
    return None #!b