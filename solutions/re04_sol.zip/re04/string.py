"""Exercise 4.3: Coutning Characters in a String."""

def count_chars(s):
    """Count the characters in a string.
    
    :param s: a string.
    
    :return: a dictionary containing the characters as keys and their counts as values.
    """
    #!b;nolines;noerror
    s = s.lower()
    char_count = {}
    for char in s:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
    return char_count #!b