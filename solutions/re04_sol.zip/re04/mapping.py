"""Exercise 4.2: Map two lists into a dictionary."""

def map_lists_into_dict(keys, values):
    """Map two lists into a dictionary.
    
    :param keys: a list of keys.
    :param values: a list of values.
    
    :return: a dictionary.
    """
    #!b;nolines;noerror
    return dict(zip(keys, values)) #!b