"""Exercise 4.1: Sort a dictionary by its values."""

def sort_dict_by_values(d):
    """Sort a dictionary by its values.
    
    :param d: a dictionary.
    
    :return: a list of tuples containing the dictionary's items, sorted by values.
    """
    #!b;nolines;noerror
    return sorted(d.items(), key=lambda x: x[1]) #!b