"""Exercises 5.11-5.13: Chemical Reaction Class"""


class Atom():
    """Create a class that stores information about an atom."""

    #!b;noerror;nolines
    def __init__(self, element, atomic_number, mass_number):
        self.element = element
        self.atomic_number = atomic_number
        self.mass_number = mass_number
    def __str__(self):
        return f"{self.element} ({self.atomic_number})"
    def get_element(self):
        return self.element
    def is_isotope(self,atom):
        if self.element == atom.element:
            if self.mass_number != atom.mass_number:
                return True
        return False
    #!b
    
class Molecule():
    """A class that stores information about a molecule."""

    #!b;noerror;nolines
    
    def __init__(self):
        self.atoms = []

    def add_atom(self, atom):
        self.atoms.append(atom)
        
    def get_atoms(self):
        return self.atoms

    def get_formula(self):
        formula = ""
        element_counts = {}
        for atom in self.atoms:
            if atom.element in element_counts:
                element_counts[atom.element] += 1
            else:
                element_counts[atom.element] = 1
        for element, count in element_counts.items():
            formula += element + (str(count) if count > 1 else "")
        return formula
    #!b

class Reaction():
    """A class that looks at a chemical reaction."""

    #!b;noerror;nolines
    
    def __init__(self, reactants, products):
        self.reactants = reactants
        self.products = products

    def balance_reaction(self):
        r = self.get_formula_count(self.reactants)
        p = self.get_formula_count(self.products)
        for i in r:
            if i in p:
                if r[i] == p[i]:
                    continue
                else:
                    return False
            else:
                return False
        return True

    def get_formula_count(self, molecules):
        count = {}
        for molecule in molecules:
            atoms = molecule.get_atoms()
            for atom in atoms:
                a = atom.get_element()
                if a in count:
                    count[a] += 1
                else:
                    count[a] = 1
        print(count)
        return count

    def __str__(self):
        reactants_str = ' + '.join([molecule.get_formula() for molecule in self.reactants])
        products_str = ' + '.join([molecule.get_formula() for molecule in self.products])
        return f"{reactants_str} -> {products_str}"
    #!b