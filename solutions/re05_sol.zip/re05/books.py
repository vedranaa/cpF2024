"""Exercise 5.4-5.6: Book Class"""

class Book:
    """Create a class that stores information about a book."""
    #!b;noerror;nolines
    def __init__(self, title, author, ISBN):
        self.title = title
        self.author = author
        self.ISBN = ISBN
    def get_title(self):
        return self.title
    def get_author(self):
        return self.author
    def get_ISBN(self):
        return self.ISBN
    def set_title(self, title):
        self.title = title
    def set_author(self, author):
        self.author = author
    def set_ISBN(self, ISBN):
        self.ISBN = ISBN
    
    def info(self):
        return f"{self.title} by {self.author}, ISBN: {self.ISBN}"

    def format_title(self,title):
        return title.title()
    #!b