"""Exercise 5.9-5.10: Library Class"""

from cp.re05.books import Book
from cp.re05.ebooks import EBook

class Library:
    """Create a class that stores information about books and ebooks."""
    #!b;noerror;nolines
    def __init__(self):
        self.books = []
        self.ebooks = []
    def add_book(self, book):
        self.books.append(book)
    def add_ebook(self, ebook):
        self.ebooks.append(ebook)
    def get_num_books(self):
        return len(self.books)
    def get_num_ebooks(self):
        return len(self.ebooks)
    def search(self, title):
        a = []
        for book in self.books:
            if title in book.get_title():
                a.append(book.info())
        for ebook in self.ebooks:
            if title in ebook.get_title():
                a.append(ebook.info())
        if len(a) == 0:
            return "Book not found"
        return a
    #!b

