"""Exercise 5.3: Temperature Class"""

class Temperature:
    """Create a class that converts between Celcius and Fahrenheit."""
    #!b;noerror;nolines
    def __init__(self,type="C",temp=0):
        if type == "C":
            self.type = "C"
            self.celcius = temp
        if type == "F":
            self.type = "F"
            self.fahrenheit = temp
    def to_celcius(self):
        if self.type == "C":
            return self.celcius
        if self.type == "F":
            return (self.fahrenheit - 32) * 5/9
    def to_fahrenheit(self):
        if self.type == "F":
            return self.fahrenheit
        if self.type == "C":
            return (self.celcius * 9/5) + 32
    def set_temp(self,temp):
        if self.type == "C":
            self.celcius = temp
        if self.type == "F":
            self.fahrenheit = temp
    def get_temp(self):
        if self.type == "C":
            return self.celcius
        if self.type == "F":
            return self.fahrenheit
    #!b