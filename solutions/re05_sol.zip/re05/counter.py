"""Exercise 5.2: Counter Class"""

class Counter():
    """Create a class that increments a count by 1."""
    #!b;noerror;nolines
    def __init__(self):
        self.count = 0
    def increment(self):
        self.count += 1
    def get_count(self):
        return self.count
    #!b