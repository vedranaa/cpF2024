"""Exercise 5.1: Names Class"""

class Full_Name():
    """Create a class that takes in a first name and last name and returns the full name."""
    #!b;noerror;nolines
    def __init__(self,First_Name,Last_Name):
        self.First_Name = First_Name
        self.Last_Name = Last_Name
    def get_full_name(self):
        return self.First_Name + " " + self.Last_Name
    #!b