"""Exercise 5.7 and 5.8: EBooks"""

from cp.re05.books import Book

class EBook(Book):
    """Create a class that stores information about an ebook."""
    
    #!b;noerror;nolines
    def __init__(self, title, author, ISBN, file_size):
        super().__init__(title, author, ISBN)
        self.file_size = file_size
    def get_file_size(self):
        return self.file_size
    def set_file_size(self, file_size):
        self.file_size = file_size
    def info(self):
        return f"{super().info()}, File Size: {self.file_size}"
    
    
d = EBook("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565", "1.5MB")
#!b