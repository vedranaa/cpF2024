"""Exercise 2.7: Gauss Jordan elimination."""

def gauss_jordan_elimination(m):
    """Perform Gauss Jordan elimination on a matrix.

    :param m: a list of lists of integers representing a matrix.

    :return: a list of lists of integers representing the matrix after Gauss Jordan elimination.
    """
    #!b;nolines;noerror
    x = len(m)
    y = len(m[0])
    for i in range(x):
        for j in range(x):
            if i != j and j > i:
                ratio = m[j][i] / m[i][i]
                for k in range(y):
                    m[j][k] -= ratio * m[i][k]
    for i in range(x):
        k = m[i][i]
        for j in range(y):
            m[i][j] = m[i][j]/k
    return m#!b