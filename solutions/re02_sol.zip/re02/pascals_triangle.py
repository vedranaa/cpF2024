"""Exercise 2.5: Pascal's triangle."""

def pascals_triangle(n):
    """Return Pascal's nth row.
    
    :param n: an integer.
    
    :return: a list of Pascal's triangles nth row.
    """
    #!b;nolines;noerror
    a = [1]
    for i in range(n):
        a.append(a[i] * (n - i) // (i + 1))
    return a#!b