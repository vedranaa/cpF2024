"""Exercise 2.11: Create all possible permutations of a string."""

def permutations(s):
    """Return all possible permutations of a string.
    
    :param s: a string.
    
    :return: a list of strings representing all possible permutations of the input string.
    """
    #!b;nolines;noerror
    if len(s) == 1:
        return [s]
    
    perms = []
    for i in range(len(s)):
        for perm in permutations(s[:i] + s[i+1:]):
            x = s[i] + perm
            if x not in perms:
                perms.append(s[i] + perm)
    return perms#!b

print(permutations('bb'))