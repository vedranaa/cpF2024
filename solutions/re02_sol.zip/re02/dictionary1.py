"""Exercise 2.2: Create a dictionary."""

def dictionary_length(l):
    """Given a list of strings, return a dictionary with the length of each string as values and the strings as keys.

    :param d: a list of strings.
    
    :return: a dictionary of strings with the length of each string as values.
    """
    #!b;nolines;noerror
    return {s: len(s) for s in l}#!b

