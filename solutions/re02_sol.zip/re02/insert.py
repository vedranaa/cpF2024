"""Exercise 2.12: Search Insert Position"""

def search_insert(nums, target):
    """Return the index where the target should be inserted in the list.
    
    :param nums: a list of integers.
    :param target: an integer.
    
    :return: an integer representing the index where the target should be inserted.
    """
    #!b;nolines;noerror
    for i in range(len(nums)):
        if nums[i] >= target:
            return i
    return len(nums)#!b