"""Exercise 2.4: Palidorome detector."""

def is_palindrome(s):
    """Return True if the input string is a palindrome, False otherwise.
    
    :param s: a string.
    
    :return: a boolean indicating whether the input string is a palindrome.
    """
    #!b;nolines;noerror
    return s == s[::-1]#!b