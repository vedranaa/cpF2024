"""Exercise 2.3: Create a dictionary again!"""

def dictionary_lengths(l):
    """Given a list of strings, return a dictionary with the length of each string as keys and a list of strings with that length as the value

    :param d: a list of strings.
    
    :return: a dictionary of strings with the length of each string as keys and a list of strings with that length as the value.
    """
    #!b;nolines;noerror
    d = {}
    for s in l:
        if len(s) in d:
            d[len(s)].append(s)
        else:
            d[len(s)] = [s]
    return d#!b
    

