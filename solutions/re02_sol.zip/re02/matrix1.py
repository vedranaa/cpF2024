"""Exercise 2.6: Calculate on a matrix."""

def calc_matrix(m,n):
    """Calculate the sum of a matrix along an axis. Make sure the matrix is rectangular.

    :param m: a list of lists of integers.
    :param n: an integer representing the axis to sum along.
    
    :return: a list of integers representing the sum of the matrix along the specified axis.
    """
    #!b;nolines;noerror
    if not all(len(row) == len(m[0]) for row in m):
        return "The matrix is not rectangular."
    if n == 0:
        return [sum(row) for row in m]
    elif n == 1:
        return [sum([row[i] for row in m]) for i in range(len(m[0]))]
    else:
        return "The axis must be 0 or 1."#!b