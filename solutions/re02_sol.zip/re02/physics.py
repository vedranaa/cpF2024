"""Exercise 2.1: Create a physics simulation."""

def simulate_motion(v1, v2, x1, x2):
    """ Simulate the motion of two objects. Tell when they will collide.
    
    :param v1: a float representing the velocity of the first object.
    :param v2: a float representing the velocity of the second object.
    :param x1: a float representing the position of the first object.
    :param x2: a float representing the position of the second object.
    
    :return: a string indicating the time when the two objects will collide.    
    """
    #!b;nolines;noerror
    if v1 == v2:
        return "The objects will never collide."
    
    t = (x1 - x2) / (v2 - v1)
    if t < 0:
        return "The objects will never collide."
    else:
        return f"The objects will collide at time {t} seconds."#!b