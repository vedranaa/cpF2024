"""Exercise 2.9: Prime factorization"""

def prime_factors(n):
    """Return a list of prime factors of the input number.
    
    :param n: an integer.
    
    :return: a list of prime factors of the input number.
    """
    #!b;nolines;noerror
    factors = []
    for i in range(2, n+1):
        while n % i == 0:
            factors.append(i)
            n = n // i
    return factors#!b