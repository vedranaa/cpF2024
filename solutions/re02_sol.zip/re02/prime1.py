"""Exercise 2.8: Is the number prime?"""

def is_prime(n):
    """Return True if the input number is prime, False otherwise.
    
    :param n: an integer.
    
    :return: a boolean indicating whether the input number is prime.
    """
    #!b;nolines;noerror
    if n < 2:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True#!b