"""Exercise 2.10: Debounce"""

def debounce(f,n):
    """Return a debounced list
    
    :param f: a list of 0s and 1s.
    :param n: an integer.
    
    :return: a list of indices where the input list f has a debounced value.
    """
    #!b;nolines;noerror
    l = []
    for i in range(len(f)):
        if f[i] != 0:
            if i+n < len(f):
                if f[i+1:i+1+n] == [0]*(n):
                    l.append(i)
            else:
                if f[i+1:] == [0]*(len(f[i+1:])):
                    l.append(i)
    return l#!b