"""Exercise 1.2: Count the number of vowels in a word."""

def count_vowels(word):
    """Count the number of vowels in a word.
    
    :param word: a string.
    
    :return: the number of vowels in the word.
    """
    #!b;nolines;noerror
    vowels = ['a', 'e', 'i', 'o', 'u']
    count = 0
    for char in word:
        if char.lower() in vowels:
            count += 1
    return count#!b