"""Exercise 1.4: Find the duplicates in a list."""

def find_duplicates(lst):
    """ Find the duplicates in a list.
    
    :param lst: a list of elements.
    
    :return: a list with the duplicates.
    """
    #!b;nolines;noerror
    duplicates = []
    for i in range(len(lst)):
        if lst[i] in lst[i+1:] and lst[i] not in duplicates:
            duplicates.append(lst[i])
    return duplicates#!b