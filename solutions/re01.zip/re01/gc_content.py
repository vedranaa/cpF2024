"""Exercise 1.7: Calculate the GC content of a DNA sequence."""

def calculate_gc_content(dna_sequence):
    """
    Calculates the GC content of a DNA sequence.

    Args:
        dna_sequence (str): The DNA sequence.

    Returns:
        float: The GC content as a percentage.
    """
    #!b;nolines;noerror
    gc_count = dna_sequence.count('G') + dna_sequence.count('C')
    total_count = len(dna_sequence)
    gc_content = (gc_count / total_count) * 100
    return gc_content#!b