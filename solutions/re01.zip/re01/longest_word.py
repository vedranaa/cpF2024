"""Exercise 1.3: Find the longest word in a list of words."""

def find_longest_word(sentence):
    """Find the longest word in a sentence.
    
    :param sentence: a string.
    
    :return: the longest word in sentence.
    """
    #!b;nolines;noerror
    words = sentence.split()
    longest_word = ""
    for word in words:
        if word.isalpha() and len(word) > len(longest_word):
            longest_word = word
    return longest_word#!b