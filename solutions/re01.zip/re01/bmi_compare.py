"""Exercise 1.10: Compare the BMI of a person over a period of time."""

def check_health(weights, heights, max_bmi_diff=1.0):
    """ Check the health of a person based on their weights and heights.
    
    :param weights: a list of floats representing the weights.
    :param heights: a list of floats representing the heights.
    :param max_bmi_diff: a float representing the maximum difference in BMI between two consecutive measurements.
    
    :return: a string indicating the health status of the person.
    """
    #!b;nolines;noerror
    for i in range(len(weights)):
        weight = weights[i]
        height = heights[i]
        bmi = weight / (height ** 2)
        print(bmi)
        if bmi > 25.0:
            return f"High BMI detected at index {i}"
        
        if i >= 1:
            prev_bmi = weights[i-1] / (heights[i-1] ** 2)
            bmi_diff = abs(bmi - prev_bmi)
            
            if bmi_diff > max_bmi_diff:
                return f"Unstable BMI detected at index {i}"
    
    return bmi#!b

result = check_health([70, 75, 80, 85], [1.70, 1.75, 1.80, 1.85], 0.1)
print(result)