"""Exercise 1.8: See if two RNA strand could make DNA."""

def is_dna_possible(rna1, rna2):
    """ Check if two RNA strands can form a DNA strand.
    
    :param rna1: a string representing the first RNA strand.
    :param rna2: a string representing the second RNA strand.
    
    :return: True if the RNA strands can form a DNA strand, False otherwise."""
    #!b;nolines;noerror
    
    # Check if the lengths of the RNA strands are equal
    if len(rna1) != len(rna2):
        return False

    # Iterate over each nucleotide in the RNA strands
    for i in range(len(rna1)):
        nucleotide1 = rna1[i]
        nucleotide2 = rna2[i]

        # Check if the nucleotides can form a DNA pair
        if (nucleotide1 == 'A' and nucleotide2 != 'T') or (nucleotide1 == 'T' and nucleotide2 != 'A'):
            return False
        elif (nucleotide1 == 'G' and nucleotide2 != 'C') or (nucleotide1 == 'C' and nucleotide2 != 'G'):
            return False

    # If all nucleotides can form DNA pairs, return True
    return True#!b