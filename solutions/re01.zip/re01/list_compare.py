"""Exercise 1.13: List comparison."""

def sum_index(list1: list, list2: list) -> int:
    """Find the index where the sum of one list is larger than the sum of another list.

    :param list1: The first list of numbers.
    :param list2: The second list of numbers.
    :return: The index where the sum of list1 is larger than the sum of list2.
    """
    #!b;nolines;noerror
    sum1 = 0
    sum2 = 0
    for i in range(len(list1)):
        sum1 += list1[i]
        sum2 += list2[i]
        if sum1 > sum2:
            return i
    return -1#!b
