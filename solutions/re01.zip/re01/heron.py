"""Exercise 1.1: Find the area of a triangle using Heron's formula."""

import math

def triangle_area(a: float, b: float, c: float):
    """Calculate and print the area of a triangle using Heron's formula.

    :param a: length of side a.
    :param b: length of side b.
    :param c: length of side c.
    """
    #!b;nolines;noerror
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    print("The area of the triangle is: {}".format(area))#!b
    
triangle_area(1,2,2)