"""Exercise 1.5: Remove duplicates from a list."""

def remove_duplicates(lst):
    """Remove duplicates from a list.

    :param lst: a list of elements.
    
    :return: a list with the duplicates removed.
    """
    #!b;nolines;noerror
    new_list = []
    for i in lst:
        if i not in new_list:
            new_list.append(i)
    return new_list#!b