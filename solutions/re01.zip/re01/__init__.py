"""Exercises for Re-exam week 1."""

