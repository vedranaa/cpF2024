"""Exercise 1.6: Reverse a sentence."""

def reverse_sentence(sentence):
    """Reverse a sentence.
    
    :param sentence: a string.
    
    :return: the sentence reversed.
    """
    #!b;nolines;noerror
    words = sentence.split()
    reversed_sentence = ' '.join(reversed(words))
    return reversed_sentence#!b