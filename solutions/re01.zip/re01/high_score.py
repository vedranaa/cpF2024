"""Exercise 1.12: Find the highest score in a list of scores."""

def highest_score(scores: list) -> float:
    """Find the highest score in a list of scores that is not the first or last score.

    :param scores: The list of scores.
    :return: The highest score in the list.
    """
    #!b;nolines;noerror
    score = max(scores[1:-1])
    return score#!b