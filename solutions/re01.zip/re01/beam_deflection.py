"""Exercise 1.9: Calculate the deflection of a beam."""

def calculate_beam_deflection(length, load, modulus_of_elasticity, moment_of_inertia):
    """
    Calculates the deflection of a beam under a given load using engineering principles.

    
    :param length (float): Length of the beam in meters.
    :param load (float): Magnitude of the load applied to the beam in newtons.
    :param modulus_of_elasticity (float): Modulus of elasticity of the beam material in pascals.
    :param moment_of_inertia (float): Moment of inertia of the beam in meters to the fourth power.
    
    :return deflection (float): Deflection of the beam in meters.
    """
    #!b;nolines;noerror
    deflection = (load * length ** 3) / (3 * modulus_of_elasticity * moment_of_inertia)
    return deflection#!b
