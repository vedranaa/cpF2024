"""Exercise 1.11: Median of a list of numbers. Easy Exam question."""


def median(numbers: list) -> float:
    """Calculate the median of a list of numbers.

    :param numbers: The list of numbers.
    :return: The median of the numbers.
    """
    #!b;nolines;noerror
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    if n % 2 == 0:
        med = (sorted_numbers[n//2 - 1] + sorted_numbers[n//2]) / 2
    else:
        med =  sorted_numbers[n//2]
    return med#!b