"""Exercise 3.12: Encrypt a file using a Ceaser cypher."""

alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

def encrypt_file(file_name, key, new_file_name):
    """Encrypt a file using a Ceaser cypher.
    
    :param file_name: a string representing the name of the file.
    :param key: an integer representing the key for the Ceaser cypher.
    :param new_file_name: a string representing the name of the new file.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.read()
    encrypted_data = ""
    for char in data:
        if char in alphabet:
            encrypted_data += alphabet[(alphabet.index(char)+key)%26]
        else:
            encrypted_data += char
    with open(new_file_name, 'w') as new_file:
        new_file.write(encrypted_data)
    return#!b