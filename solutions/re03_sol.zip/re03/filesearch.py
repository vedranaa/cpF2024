"""Exercise 3.4: Search a file for a word and return the line number and the line."""

def search_word(file_name, word):
    """Search a file for a word and return the line number and the line.
    
    :param file_name: a string representing the name of the file.
    :param word: a string representing the word to search for.
    
    :return: a tuple containing the line number and the line where the word was found.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.readlines()
    for i, line in enumerate(data):
        if word in line:
            return i+1, line
    return -1, ""#!b