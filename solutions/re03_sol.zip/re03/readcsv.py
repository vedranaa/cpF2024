"""Exercise 3.3: Read a CSV file and return the data as a list of lists."""

def read_csv(file_name):
    """Read a CSV file and return the data as a list of lists.
    
    :param file_name: a string representing the name of the file.
    
    :return: a list of lists of floats containing the data in the CSV file.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.readlines()
    x = []
    for line in data:
        x.append([float(i) for i in line.split(',')])
    return x#!b