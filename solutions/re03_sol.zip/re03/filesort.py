"""Exercise 3.5: Sort a file and write the sorted lines to a new file."""

def sort_file(file_name, new_file_name):
    """Sort a file and write the sorted lines to a new file.
    
    :param file_name: a string representing the name of the file.
    :param new_file_name: a string representing the name of the new file.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.readlines()
    data.sort()
    with open(new_file_name, 'w') as new_file:
        for line in data:
            new_file.write(line)
    return#!b