"""Exercise 3.7: Return the total number of files with a specific extension in a folder."""

import os

def extensions(path, extension):
    """Return the total number of files with a specific extension in a folder.
    
    :param path: a string representing the path of the folder.
    :param extension: a string representing the extension of the files.
    
    :return: an integer representing the total number of files with the specific extension.
    """
    #!b;nolines;noerror
    num = 0
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(extension):
                num += 1
    return num #!b