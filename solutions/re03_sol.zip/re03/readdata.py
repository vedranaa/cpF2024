"""Exercise 3.11: Read a Data file and return the data as a list of lists and parameters as a dictionary."""

def read_data(file_name):
    """Read a txt file that contains two lists and a dictionary. 
    All the dictionary lines start with "#", and the key and values are seperated by a colon. 
    Some of the parameters come after the colon, and should be split by a "=".
    The lists are seperated by a blank line.
    
    :param file_name: a string representing the name of the file.
    
    :return: a tuple containing two lists and a dictionary.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.readlines()
    dictio = {}
    list1 = []
    for line in data:
        if line[0] == "#":
            if "=" in line:
                key, value = line.strip().split(":")
                value = value.split("=")
                dictio[value[0]] = value[1]
            else:
                key, value = line.strip().split(":")
                dictio[key] = value
        else:
            if line == "\n":
                continue
            list1.append(line.strip().split(" "))
    
    return list1, dictio #!b