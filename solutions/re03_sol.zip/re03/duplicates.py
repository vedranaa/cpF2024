"""Exercise 3.10: Find duplicate files in a folder."""

import os

def duplicates(path):
    """Find duplicate files in a folder.
    
    :param path: a string representing the path of the folder.
    
    :return: a dictionary containing the duplicate files.
    """
    #!b;nolines;noerror
    big_files = {}
    for root, dirs, files in os.walk(path):
        for file in files:
            if file in big_files:
                big_files[file] +=1
            else:
                big_files[file] = 0
    return {k: v for k, v in big_files.items() if v > 1}#!b