"""Exercise 3.9: Split a file into smaller files."""

import os

def split_file(file_name, size):
    """Split a file into smaller files.
    
    :param file_name: a string representing the name of the file.
    :param size: an integer representing the size of the smaller files.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        data = file.read()
    
    num_files = len(data) // size
    for i in range(num_files):
        with open(f'{file_name}_{i+1}', 'w') as new_file:
            if i == num_files - 1:
                new_file.write(data[i*size:])
            else:
                new_file.write(data[i*size:(i+1)*size])
    return#!b