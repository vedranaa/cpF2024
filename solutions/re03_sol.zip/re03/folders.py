"""Exercise 3.6: Return the total numbers of folders and subfolders in a folder."""

import os

def folders(path):
    """Return the total numbers of folders and subfolders in a folder.
    
    :param path: a string representing the path of the folder.
    
    :return: a tuple containing the total numbers of folders and subfolders.
    """
    #!b;nolines;noerror
    folders = 0
    for root, dirs, files in os.walk(path):
        folders += len(dirs)
    return folders #!b