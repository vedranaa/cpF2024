"""Exercise 3.8: Find the lines in which there are differences between two files."""  

def diff(file1, file2):
    """Find the lines in which there are differences between two files.
    
    :param file1: a string representing the name of the first file.
    :param file2: a string representing the name of the second file.
    
    :return: a list containing the lines in which there are differences.
    """
    #!b;nolines;noerror
    with open(file1, 'r') as f1:
        lines1 = f1.readlines()
    with open(file2, 'r') as f2:
        lines2 = f2.readlines()
    
    differences = []
    for i in range(min(len(lines1),len(lines2))):
        if lines1[i] != lines2[i]:
            differences.append(i)
    if len(lines1) > len(lines2):
        differences.extend(range(len(lines2), len(lines1)))
    elif len(lines1) < len(lines2):
        differences.extend(range(len(lines1), len(lines2)))
    return differences #!b