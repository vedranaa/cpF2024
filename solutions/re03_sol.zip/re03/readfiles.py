"""Exercise 3.1: Read a file and return the number of lines, words, and characters."""

def read_file(file_name):
    """Read a file and return the number of lines, words, and characters.
    
    :param file_name: a string representing the name of the file.
    
    :return: a tuple containing the number of lines, words, and characters in the file.
    """
    #!b;nolines;noerror
    with open(file_name, 'r') as file:
        lines = file.readlines()
    with open(file_name, 'r') as file:
        words = file.read().split()
    with open(file_name, 'r') as file:
        characters = file.read()
        
    return len(lines), len(words), len(characters)#!b