"""Exercise 3.2: Write the input to a file."""

def write_file(file_name, text):
    """Write the input to a file.
    
    :param file_name: a string representing the name of the file.
    :param text: a string representing the text to be written to the file.
    """
    #!b;nolines;noerror
    with open(file_name, 'w') as file:
        file.write(text)
    return#!b