"""Exercise 3.13: Visual representation of the folder and file structure."""

import os

def visualrep(path):
    """Visual representation of the folder and file structure.
    
    :param path: a string representing the path of the folder.
    """
    #!b;nolines;noerror
    for root, dirs, files in os.walk(path):
        level = root.replace(path, '').count(os.sep)
        indent = '-' * 4 * level
        print(f'{indent}{os.path.basename(root)}/')
        subindent = '-' * 4 * (level + 1)
        for file in files:
            print(f'{subindent}{file}')
    return#!b