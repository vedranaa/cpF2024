"""Exercise 3.3: Read a CSV file and return the data as a list of lists."""
import csv

def read_csv(file_name):
    """Read a CSV file and return the data as a list of lists.
    
    :param file_name: a string representing the name of the file.
    
    :return: a list of lists of floats containing the data in the CSV file.
    """
    with open(file_name,"r") as f:
        csvreader = csv.reader(f)
        data = []

        for row in csvreader:
            data.append([])
            for data_point in row:
                data[-1].append(float(data_point))

        return data

    with open(file_name,"r") as f:
        csvreader = csv.reader(f,quoting=csv.QUOTE_NONNUMERIC)    
        return list(csvreader)
    
    

print(read_csv("files/csv1.csv"))