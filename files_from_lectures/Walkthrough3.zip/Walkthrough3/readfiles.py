"""Exercise 3.1: Read a file and return the number of lines, words, and characters."""

def read_file(file_name):
    """Read a file and return the number of lines, words, and characters.
    
    :param file_name: a string representing the name of the file.
    
    :return: a tuple containing the number of lines, words, and characters in the file.
    """
    l,w,c = 0,0,0
    with open(file_name,"r") as f:
        linelist = f.readlines()
        
        l = len(linelist)

        for line in linelist:
            w += len(line.split())
            c += len(line)

            
    return l,w,c
