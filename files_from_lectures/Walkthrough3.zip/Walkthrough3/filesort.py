"""Exercise 3.5: Sort a file and write the sorted lines to a new file."""

def sort_file(file_name, new_file_name):
    """Sort a file and write the sorted lines to a new file.
    
    :param file_name: a string representing the name of the file.
    :param new_file_name: a string representing the name of the new file.
    """

        
    with open(file_name,"r") as f:
        linelist = f.readlines()
        data = []
        for line in linelist:
            data.append(int(line))
        data.sort()
        with open(new_file_name,"w") as nf:
            for number in data:
                nf.write(str(number) + "\n") ##remember to add end line
        