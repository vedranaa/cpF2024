"""Exercise 3.6: Return the total numbers of folders and subfolders in a folder."""

import os

def folders(path):
    """Return the total numbers of folders and subfolders in a folder.
    
    :param path: a string representing the path of the folder.
    
    :return: a tuple containing the total numbers of folders and subfolders.
    """ 
    return len(list(os.walk(path)))-1
    

