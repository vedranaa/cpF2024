"""Exercise 2.2: Create a dictionary."""

def dictionary_length(l):
    """Given a list of strings, return a dictionary with the length of each string as values and the strings as keys.

    :param l: a list of strings.
    
    :return: a dictionary of strings with the length of each string as values.
    """
    # TODO: Code has been removed from here. 

    d = dict()

    for word in l:

        d[word] = len(word)

    return d

print(dictionary_length(["hello", "world", "python", "programming", "language"]))