"""Exercise 2.13: Anagrams"""

def anagrams(l):
    """Given a list of strings, return a list of lists containing all anagrams.

    :param l: a list of strings.
    
    :return: a list of lists containing all anagrams.
    """
    # TODO: Code has been removed from here. 
