"""Exercises for Brush-up week 2."""
