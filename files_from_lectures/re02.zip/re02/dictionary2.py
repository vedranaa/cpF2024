"""Exercise 2.3: Create a dictionary again!"""

def dictionary_lengths(l):
    """Given a list of strings, return a dictionary with the length of each string as keys and a list of strings with that length as the value

    :param l: a list of strings.
    
    :return: a dictionary of strings with the length of each string as keys and a list of strings with that length as the value.
    """
    # TODO: Code has been removed from here. 

    d = dict()

    for word in l:
        word_len = len(word)
        if word_len in d:
            d[word_len] = d[word_len] + [word]
        else:
            d[word_len] = [word]

    return d

print(dictionary_lengths(["hello", "world", "python", "programming", "language"]))
