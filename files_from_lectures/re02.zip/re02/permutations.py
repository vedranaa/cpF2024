"""Exercise 2.11: Create all possible permutations of a string."""

def permutations(s):
    """Return all possible permutations of a string.
    
    :param s: a string.
    
    :return: a list of strings representing all possible permutations of the input string.
    """
    # TODO: Code has been removed from here. 
    '''
    if len(s) <= 1:
        return [s]
    res = []
    for i in range(len(s)):
        res += [s[i] + p for p in permutations(s[0:i] + s[i+1:])]
    return sorted(list(set(res)))
    '''
print(permutations('bb'))
print(permutations("abcdd"))
