"""Exercise 2.5: Pascal's triangle."""

def pascals_triangle(n):
    """Return Pascal's nth row.
    
    :param n: an integer.
    
    :return: a list of Pascal's triangles nth row.
    """
    # TODO: Code has been removed from here. 
    line = [1]
    
    for j in range(n):
        newline = []
        
        for i in range(len(line) + 1):
            if i == 0:
                newline.append(1)
            elif i == len(line):
                newline.append(1)
            else:
                newline.append(line[i] + line[i-1])
        line = newline

    return line

for i in range(10):
    print(pascals_triangle(i))