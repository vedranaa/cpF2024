"""Exercise 2.4: Palidorome detector."""

def is_palindrome(s):
    """Return True if the input string is a palindrome, False otherwise.
    
    :param s: a string.
    
    :return: a boolean indicating whether the input string is a palindrome.
    """
    # TODO: Code has been removed from here. 

    s = s.lower()

    while s.isalnum() == False:
        for character in s:
            if not character.isalnum():
                s = s.replace(character,"")
                break

    
    return s == s[::-1]


print(is_palindrome("@abba"))
print(is_palindrome("baba"))