"""Exercise 2.8: Is the number prime?"""

def is_prime(n):
    """Return True if the input number is prime, False otherwise.
    
    :param n: an integer.
    
    :return: a boolean indicating whether the input number is prime.
    """
    # TODO: Code has been removed from here. 
