"""Exercise 2.1: Create a physics simulation."""

def simulate_motion(v1, v2, x1, x2):
    """ Simulate the motion of two objects. Tell when they will collide.
    
    :param v1: a float representing the velocity of the first object.
    :param v2: a float representing the velocity of the second object.
    :param x1: a float representing the position of the first object.
    :param x2: a float representing the position of the second object.
    
    :return: a string indicating the time when the two objects will collide.    
    """
    # TODO: Code has been removed from here. 
    if x1 - x2 == 0:
        return "The objects will collide at time 0 seconds."
    if v2 - v1 == 0:
        return "The objects will never collide."

    t = (x1-x2) / (v2-v1)

    if t < 0:
        return "The objects will never collide."
    
    return f"The objects will collide at time {t} seconds." #"The objects will collide at time " + str(t) + " seconds."
    
    
print(simulate_motion(1, 2, 3, 6))




