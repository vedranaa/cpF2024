"""Exercise 2.6: Calculate on a matrix."""

def calc_matrix(m,n):
    """Calculate the sum of a matrix along an axis. Make sure the matrix is rectangular.

    :param m: a list of lists of integers.
    :param n: an integer representing the axis to sum along.
    
    :return: a list of integers representing the sum of the matrix along the specified axis.
    """
    # TODO: Code has been removed from here.    
    
    if not (n == 0 or n == 1):
        return "The axis must be 0 or 1."  

    l = len(m[0]) 
    for i in range(1,len(m)):
        if len(m[i]) != l:
            return "The matrix is not rectangular."
        
    sum_list = []

    if n == 0:
        for i in range(len(m)):
            row_sum = 0
            for j in range(len(m[0])):
                row_sum += m[i][j]
            sum_list.append(row_sum)

    else:
        for i in range(len(m[0])):
            column_sum = 0
            for j in range(len(m)):
                column_sum += m[j][i]
            sum_list.append(column_sum)

    return sum_list

print(calc_matrix([[1,2,3],[4,5,6],[7,8,9]],1))

