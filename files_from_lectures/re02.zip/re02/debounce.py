"""Exercise 2.10: Debounce"""

def debounce(f,n):
    """Return a debounced list
    
    :param f: a list of 0s and 1s.
    :param n: an integer.
    
    :return: a list of indices where the input list f has a debounced value.
    """
    # TODO: Code has been removed from here. 
