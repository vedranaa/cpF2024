"""Exercise 2.9: Prime factorization"""

def prime_factors(n):
    """Return a list of prime factors of the input number.
    
    :param n: an integer.
    
    :return: a list of prime factors of the input number.
    """
    # TODO: Code has been removed from here. 
